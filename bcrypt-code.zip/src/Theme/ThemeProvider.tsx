import { useEffect, useState, ReactNode } from 'react';

const LOCAL_STORAGE_KEY = "theme";
 const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    const initialTheme = stored || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', initialTheme === 'dark');
    setTheme(initialTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    localStorage.setItem(LOCAL_STORAGE_KEY, newTheme);
    setTheme(newTheme);
  };

  return (
    <>
      <button onClick={toggleTheme} className="fixed top-4 right-4 z-50 p-2 rounded-2xl bg-gray-700 text-white">
        Toggle {theme === 'dark' ? 'Light' : 'Dark'}
      </button>
      {children}
    </>
  );
};
export default ThemeProvider;