import { motion } from "framer-motion";
import Lottie from "lottie-react";
import cyberAnimation from "../assets/cyber-security.json"
import { useNavigate } from "react-router-dom";

const LandingPage = () => {
  const navigate = useNavigate();
  return (
    <section className="relative flex items-center justify-center dark:bg-gray-800
     min-h-screen bg-gradient-to-r  from-purple-400 via-green-600 to-blue-500 opacity-80
     text-white mt-3  overflow-hidden">
      {/* Lottie Background */}
      <motion.div
  initial={{ x: 100, opacity: 0 }}
  animate={{ x: 0, opacity: 0.2 }}
  transition={{ delay: 0.4, duration: 1 }}
  className="absolute right-0 top-1/2 -translate-y-1/2 z-0"
>
  <Lottie
    animationData={cyberAnimation}
    loop
    className=" object-cover"
  />
</motion.div>

      {/* Blur effect */}
      {/* <div className="absolute w-[500px] h-[500px] bg-blue-600 blur-[150px] rounded-full opacity-40 top-[-50px] right-[-100px]" /> */}
      <div className="absolute w-[200px] h-[200px] bg-blue-600 blur-[150px] 
      rounded-full opacity-40 top-[-50px] right-[-100px]" />

      {/* Main Content */}
      <div className="z-10 text-center px-4">
        <motion.h1
          className="text-4xl md:text-6xl font-extrabold"
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          Online Bcrypt Hash Generator & Checker
        </motion.h1>
        <motion.p className="mt-4 text-lg md:text-xl" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>Secure your passwords using bcrypt hashing & verification.</motion.p>
      <motion.button onClick={() => navigate("/tool")}
        className="mt-6 px-6 py-3 rounded-md bg-blue-600 hover:bg-blue-700 transition"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}>
        Go to Tool
      </motion.button>
      </div>
    </section>
  );
};

export default LandingPage;
