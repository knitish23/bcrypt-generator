import BcryptTool from "./BcryptTool";

const ToolPage = () => {
  return (
    <div className="p-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 text-white dark:bg-gray-900">
      <BcryptTool />
    </div>
  );
};

export default ToolPage;
