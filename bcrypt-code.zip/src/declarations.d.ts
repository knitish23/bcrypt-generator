declare module 'vanta/dist/vanta.globe.min';
declare module 'vanta/dist/vanta.net.min';
declare module 'vanta/dist/vanta.waves.min';